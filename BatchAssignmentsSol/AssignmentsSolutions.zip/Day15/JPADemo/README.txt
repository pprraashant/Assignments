use this url to check in memory database 
http://localhost:8080/h2-console
and connection string -jdbc:h2:mem:testdb