package fooddemo;

public class CreateMeal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Meal meal = new Meal();
		Fruit fruit=new Fruit();
		fruit.setMyName("Mango");
		Apple apple= new Apple();
		apple.setDefinition("I am ");
		apple.setName("Apple");
		
		Dairy dairy= new Dairy();
		dairy.setMyName("Milk");
		dairy.talkaboutYourself();
		
		
		meal.setFruit(apple);
		meal.setDairy(dairy);
		
		System.out.println(meal.whatsInThisMeal());
		apple.destoryMethod();
	}

}
