package fooddemo;

public class HelloWorld {
	
	String msg;
	
	HelloWorld()
	{
		
	}
	
	HelloWorld(String message)
	{
		System.out.println("I am in Hello World Construtor");
		this.msg=message;
	}
	
	public String getMessage()
	{
		return msg;
	}

}
