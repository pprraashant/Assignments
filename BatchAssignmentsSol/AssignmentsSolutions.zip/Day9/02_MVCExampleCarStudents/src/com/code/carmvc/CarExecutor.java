package com.code.carmvc;

import com.code.carmvc.model.Car;
import com.code.carmvc.view.CarView;
import com.code.controller.CarController;

public class CarExecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CarController carController= new CarController(new Car(), new CarView());
		
		carController.setCarMake("2008");
		carController.setCarSpeed();
		carController.updateCarView();
		
	}

}
