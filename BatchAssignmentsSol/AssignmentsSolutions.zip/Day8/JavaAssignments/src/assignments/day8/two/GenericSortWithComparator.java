package assignments.day8.two;

import java.util.Comparator;

public class GenericSortWithComparator {
	
	public static <T> T [] selectionSort(T[] arr, Comparator<? super T> comp) {
			 for (int i = 0; i < arr.length - 1; ++i) {
			 int minIndex = i;
			 for (int j = i+1; j < arr.length; ++j) {
			 if (comp.compare(arr[j], arr[minIndex])<0) {
			 minIndex = j;
			 }
			 }
			 T temp = arr[i];
			 arr[i] = arr[minIndex];
			 arr[minIndex] = temp;
			 }
			 return arr;
			 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer [] a = new Integer [] {2,5,3,1,0,12,4};

		a= selectionSort(a,Comparator.naturalOrder());
		for(int value:a)
		{
			System.out.println(value);
		}
		String [] str = new String [] {"2","5","3","1","0","12","4"};

		str= selectionSort(str,Comparator.naturalOrder());
		for(String value:str)
		{
			System.out.println(value);
		}
	}

}
