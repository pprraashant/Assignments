package assignments.day8.four;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SumExecutorServiceFutureResult {
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		
		
		  List<Callable<Long>> tasks = new ArrayList<>();
			  
			  for (int j = 0; j <100; j++) {
				  Counter count = new Counter();
	        		tasks.add(() -> { return (long) count.increment(); });
			  }
	        ExecutorService executor = Executors.newFixedThreadPool(1);
	        List<Future<Long>> results = executor.invokeAll(tasks);
	        long total = 0;
	        for (Future<Long> result : results) total += result.get();
	        System.out.println("Occurrences of " + "" + ": " + total);
	 
	}
	
}
