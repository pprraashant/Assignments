package assignments.day8.four;

public class Counter {
    private int sum;
    private static int start=0;
    private static int till=1000;
    public synchronized int increment() {
    	
        for(int i=start;i<=till;i++)
        {
        	sum=sum+i;
        }
        return sum;
    }
}