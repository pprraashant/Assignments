package assignments.day8.three;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class CompilerProcess {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		System.out.print("Started Executing");
		String currentDirectory = System.getProperty("user.dir");
		String filename= currentDirectory+"\\src\\day\\two";
		String javaClass= currentDirectory+"\\src";
		final Process compile = new ProcessBuilder("javac.exe", filename+"\\GenericSortWithComparator.java").start();
		compile.waitFor();
		final Process p = new ProcessBuilder("java.exe", "-cp",javaClass,"day.two.GenericSortWithComparator").start();
		InputStream processOut = p.getInputStream();
		Scanner in = new Scanner(processOut);
		while (in.hasNextLine()) System.out.println(in.nextLine());
		p.waitFor();
		System.out.print("outputofProgram from same program");

	}

}
