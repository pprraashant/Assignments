package com.code.config;

import org.springframework.context.annotation.ComponentScan;


@ComponentScan(basePackages="com.code.service")
public class RootConfig {

}
