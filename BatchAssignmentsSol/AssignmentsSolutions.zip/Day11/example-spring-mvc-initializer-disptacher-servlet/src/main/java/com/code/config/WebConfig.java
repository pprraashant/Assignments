package com.code.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@EnableWebMvc
@ComponentScan("com.code.controller")
public class WebConfig {
	
	@Bean
	public InternalResourceViewResolver viewResolver()
	{
	
	InternalResourceViewResolver view = new InternalResourceViewResolver();
	view.setPrefix("WEB-INF/views/");
	view.setSuffix(".jsp");
	
	return view;
	}

}
