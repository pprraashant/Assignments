package com.code.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.code.service.GreetingService;

@Controller
//@RequestMapping("/spring")
public class MainController {
	
	@Autowired
	GreetingService greetingservice;
	
	@RequestMapping (value= "/", method=RequestMethod.GET, params="a=10")
	public String displayMessage(Model model)
	{
		System.out.println("i am inside displayMessage with param as a=10");
		model.addAttribute("message",greetingservice.greet());
		model.addAttribute("newmsg","I am new Message");
		return "home";
	}
	@RequestMapping (path= "/{id}", method=RequestMethod.GET)
	@ResponseBody
	public String displayMessageWithoutView(Model model,@PathVariable int id,@RequestParam int a)
	{
		System.out.println("i am inside displayMessage with id "+id+ "param as a=10");
		model.addAttribute("message",greetingservice.greet());
		return "Id is "+id +"queryParam "+ a;
	}
	@GetMapping("/home")
	public String displayMessageWithGetMapping(Model model)
	{
		System.out.println("i am inside displayMessageWithGetMapping");
		model.addAttribute("message",greetingservice.greet());
		return "home";
	}
	
	@GetMapping("/all")
	@ResponseBody
	public String all(Model model)
	{
		System.out.println("i am inside all");
		model.addAttribute("message",greetingservice.greet());
		return "home";
	}
	
	
	@GetMapping("/res")
	@ResponseBody
	public ResponseEntity<String> reponseEntity(Model model)
	{
		System.out.println("i am inside all");
		model.addAttribute("message",greetingservice.greet());
		//return ResponseEntity.ok().body("I am inside ResponseEntity");
		return ResponseEntity.ok().body("Some wrong inputs provided");
	}
	

}
