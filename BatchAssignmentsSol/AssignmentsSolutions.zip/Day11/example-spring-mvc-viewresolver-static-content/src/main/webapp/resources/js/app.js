function message() {
    alert("hello!!!");
}