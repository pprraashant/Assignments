package com.oreilly.mvc.data.services;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.oreilly.mvc.data.entities.Car;

@Component
public class CarService {

		private List<Car> projects = new LinkedList<>();
		
		public CarService(){
			Car javaProject = this.createProject("Mercedense Benz", "This is a super Car" );
			Car javascriptProject = this.createProject("Tesla", "This is a electric Car");
			Car htmlProject = this.createProject("Yulu Car", "This is an startup project");
			
			this.projects.addAll(Arrays.asList(new Car[]{javaProject, javascriptProject, htmlProject}));
		}
		
		public List<Car> findAll(){
			return this.projects;
		}
		
		public Car find(Long projectId){
			return this.projects.stream().filter(p -> {
				return p.getCarId().equals(projectId);
			}).collect(Collectors.toList()).get(0);
		}

		private Car createProject(String title, String description) {
			Car project = new Car();
			project.setName(title);
			project.setNoHoursLifeTimeOfCar(new BigDecimal("100000"));
			project.setnoHoursBeforeService(new BigDecimal("1000"));
			project.setCarId(1L);
			project.setSpecial(false);
			project.setType("multi");
			project.setYear("2015");
			project.setDescription(description);
			return project;
		}
		
		
		
}
