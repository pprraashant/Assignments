package com.oreilly.mvc.controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oreilly.mvc.data.entities.Car;
import com.oreilly.mvc.data.services.CarService;;

@Controller
@RequestMapping("/car")
public class CarController {

	@Autowired
	public CarService carService;

	@RequestMapping(value="/{carId}")
	public String findcar(Model model, @PathVariable Long carId) {
		model.addAttribute("car", this.carService.find(carId));
		return "car";
	}
	
	@RequestMapping(value="/find")
	public String find(Model model) {
		model.addAttribute("cars", this.carService.findAll());
		return "cars";
	}
	
	@RequestMapping(value="/add",method=RequestMethod.GET)
	public String addcar(Model model){

		model.addAttribute("types", new ArrayList<String>(){{
			add("");
			add("Single Year");
			add("Multi Year");
		}});
		
		model.addAttribute("car", new Car());

		return "car_add";
	}

	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String savecar(@ModelAttribute Car car) {
		System.out.println("invoking save car");
		System.out.println(car);
		return "car_add";
	}

	
}
