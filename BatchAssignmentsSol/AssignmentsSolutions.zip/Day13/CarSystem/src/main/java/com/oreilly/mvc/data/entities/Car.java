package com.oreilly.mvc.data.entities;

import java.math.BigDecimal;
import java.util.List;

public class Car {

	private Long carId;

	private String name;

	private String description;

	private Sponsor sponsor;

	private BigDecimal noHoursBeforeService;

	private BigDecimal noHoursLifeTimeOfCar;

	private String year;

	private boolean special;

	private String type;

	private List<String> pointsOfContact;

	public Long getCarId() {
		return carId;
	}

	public void setCarId(Long carId) {
		this.carId = carId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getnoHoursBeforeService() {
		return noHoursBeforeService;
	}

	public void setnoHoursBeforeService(BigDecimal authorizedHours) {
		this.noHoursBeforeService = authorizedHours;
	}

	public BigDecimal getNoHoursLifeTimeOfCar() {
		return noHoursLifeTimeOfCar;
	}

	public void setNoHoursLifeTimeOfCar(BigDecimal authorizedFunds) {
		this.noHoursLifeTimeOfCar = authorizedFunds;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Sponsor getSponsor() {
		return sponsor;
	}

	public void setSponsor(Sponsor sponsor) {
		this.sponsor = sponsor;
	}

	public boolean isSpecial() {
		return special;
	}

	public void setSpecial(boolean special) {
		this.special = special;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getPointsOfContact() {
		return pointsOfContact;
	}

	public void setPointsOfContact(List<String> pointsOfContact) {
		this.pointsOfContact = pointsOfContact;
	}

	@Override
	public String toString() {
		return "Car [carId=" + carId + ", name=" + name + ", description=" + description + ", sponsor="
				+ sponsor + ", noHoursBeforeService=" + noHoursBeforeService + ", noHoursLifeTimeOfCar=" + noHoursLifeTimeOfCar + ", year="
				+ year + ", special=" + special + ", type=" + type + ", pointsOfContact=" + pointsOfContact + "]";
	}

}
