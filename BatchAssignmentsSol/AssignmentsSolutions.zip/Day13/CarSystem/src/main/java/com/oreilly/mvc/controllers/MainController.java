package com.oreilly.mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oreilly.mvc.data.entities.Car;
import com.oreilly.mvc.data.entities.Sponsor;

@Controller
@RequestMapping("/home")
public class MainController {

	@RequestMapping("/")
	public String greeting(Model model) {
		
		Car car = new Car();
		car.setName("First Car");
		car.setSponsor(new Sponsor("NASA", "555-555-5555", "nasa@nasa.com"));
		car.setDescription("This is a simple car sponsored by Nasa");
		
		model.addAttribute("currentCar", car);
		
		return "home";
	}
	
}
