do mvn package for first project which will generate the war file in target folder 
deploy same in tomcat webapps folder