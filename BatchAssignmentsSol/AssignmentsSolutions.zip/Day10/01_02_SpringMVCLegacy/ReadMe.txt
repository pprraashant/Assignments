use application home as -01_02_SpringMVCLegacy

http://localhost:8080/app/