package processbuilder;
import java.io.*;
import java.util.Scanner;

public class ProcessBuilderExample {
	
		public static void main(String [] a) throws IOException, InterruptedException
		{
			
//			ProcessBuilder builder = new ProcessBuilder("dir");
//			Process p = builder.directory(new File("bash")).start();
			final Process p = new ProcessBuilder("CMD", "/C", "dir").start();
			InputStream processOut = p.getInputStream();
			try (Scanner in = new Scanner(processOut);)
			{
			while (in.hasNextLine()) System.out.println(in.nextLine());
			p.waitFor();
			}
			
		}
}
