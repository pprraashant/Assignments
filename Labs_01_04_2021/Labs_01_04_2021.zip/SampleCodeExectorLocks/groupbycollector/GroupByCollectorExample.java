package groupbycollector;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GroupByCollectorExample {
	static String lastException = "";
	final static String matcherString= "Exception";
	
	@SuppressWarnings("resource")
	public static void main(String p[]) throws IOException
	{
		
		Path logsPath = Paths.get("ErrorLogs.log");
		Stream<String> lines = Files.lines(logsPath);
		
		Map<String, Set<String>> countryToLocaleSet = lines.collect(Collectors.
				groupingBy((str)-> {
					if(str.contains(matcherString))
					{
						lastException=str;
						return str;
					}
						
					else
					return lastException;
				}, Collectors.toSet()));
		//System.out.println(countryToLocaleSet);
		
		Set<String> logs =countryToLocaleSet.get("Exception in thread \"main\" java.lang.Exception");
		logs.stream().forEach(System.out::println);
	}
	
	@FunctionalInterface
	interface ReturnMatachingLine {
		
		String returnMatchedLine(String str);
	}

}
