package objectStream;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ReadObjectFromFile {

	public static void main(String[] args) throws IOException, ClassNotFoundException {

		
		Path path = Paths.get("employee142021.dat");
		
		try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(path))) {
			// retrieve all records into a new array

			Employee[] newStaff = (Employee[]) in.readObject();

			// raise admin's salary
			newStaff[2].raiseSalary(10);

			// print the newly read employee records
			for (Employee e : newStaff)
				System.out.println(e);
	}
}
}
