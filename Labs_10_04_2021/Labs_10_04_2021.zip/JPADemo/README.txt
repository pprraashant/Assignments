H2 
use this url to check in memory database
1.enable only H2 in pom comment all other database dependancies

<!-- 		<dependency> <groupId>org.springframework</groupId> <artifactId>spring-jdbc</artifactId> 
			</dependency> -->
			<!-- 		<dependency> <groupId>mysql</groupId> <artifactId>mysql-connector-java</artifactId> 
			<scope>runtime</scope> </dependency> -->
2. all comment below in properties file

#spring.datasource.url=jdbc:mysql://localhost:3306/flatsdb
#spring.datasource.username=root
#spring.datasource.password=password
#spring.datasource.driver-class-name=com.mysql.jdbc.Driver
#spring.jpa.database-platform = org.hibernate.dialect.MySQL5Dialect
#spring.jpa.generate-ddl=true
#spring.jpa.hibernate.ddl-auto = update

  
http://localhost:8080/h2-console
and connection string -jdbc:h2:mem:testdb