package com.code.abtractclass;

public abstract class AirIndia {
	
	abstract int calculateAmount(String ticket);
	
	 void book()
	{
	 System.out.println("Booking is handled by AirIndia");
	}

}
