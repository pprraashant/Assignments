package com.code.abtractclass;

public class FlipKartAirTicketApp extends AirIndia {

	@Override
	void book() {
		// TODO Auto-generated method stub
		
		System.out.println("booking ticket for airIndia from flipKart");

	}

	@Override
	int calculateAmount(String ticket) {
		// TODO Auto-generated method stub
		return 0;
	}

}
