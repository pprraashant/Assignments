package com.code.abtractclass;

public class AmazonAirTicketApp extends AirIndia{


	@Override
	int calculateAmount(String ticket) {
		// TODO Auto-generated method stub
		return 0;
	}

}
