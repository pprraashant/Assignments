package com.code.inputbufferscanner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BufferedReaderExample {
	
	public static void main(String [] args) throws IOException
	{
		System.out.println("Input your input here:\n");
		BufferedReader reader= new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Your input is "+reader.readLine());
		reader.close();
		//System.out.println("Your input is "+reader.readLine()); IOException
	}

}
