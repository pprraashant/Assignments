package com.code.inputbufferscanner;

import java.util.Scanner;

public class ScannerExample {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		
		while(sc.hasNext())
		{
			System.out.println(sc.next());
		}

	}

}
