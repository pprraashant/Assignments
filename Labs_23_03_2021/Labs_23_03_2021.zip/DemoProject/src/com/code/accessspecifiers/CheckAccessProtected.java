package com.code.accessspecifiers;

public class CheckAccessProtected {
	
	protected int data=0;
	private int privateData;

	public static void main(String[] args) {
		
		System.out.println("check the access");
		
	}

}
