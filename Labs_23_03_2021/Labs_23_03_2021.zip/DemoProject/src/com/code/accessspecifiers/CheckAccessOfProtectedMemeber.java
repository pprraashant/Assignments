package com.code.accessspecifiers;

public class CheckAccessOfProtectedMemeber {

	public static void main(String[] args) {
		
		CheckAccessProtected checkAccess= new CheckAccessProtected();
		
		System.out.println(checkAccess.data);

	}

}
