package com.code.accessspecifiers.animals;

import com.code.accessspecifiers.Animal;

public class Cat extends Animal {
	
	int age;
	int previousAge;
	
	void setrangeAge(int...age)
	{
		this.age=age[0];
		previousAge=age[1];
	}
	
	public static void main(String p[])
	{
		Cat c= new Cat(); 
		c.setName("Pillu");
		System.out.println(c.name);
		
		c.setrangeAge(4,2);
		//System.out.println(c.type); No default access
		System.out.println("CurrrentAge "+ c.age);
		System.out.println("Previous age "+c.previousAge);
	}

}
