package com.code.accessspecifiers.animals;

public class CheckAccess extends Object{
	
	public static void main(String p[])
	{
		Cat c= new Cat(); 
		c.setName("Pillu");
		//System.out.println(c.name); No access
	}

}
