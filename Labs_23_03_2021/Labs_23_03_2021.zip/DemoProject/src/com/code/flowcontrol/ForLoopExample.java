package com.code.flowcontrol;

public class ForLoopExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=0;i<=5;i++)
		{
			sum=sum+i;
			if(sum==10)
			break;
		}
		System.out.println("Sum is "+sum);

	}

}
