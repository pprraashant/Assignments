package com.code.flowcontrol;

public class SwitchExample {
	
	public static void main(String p[])
	{
		int a=11;
		
		switch(a)
		{
		case 7:
		case 5:
		case 9:
			System.out.println("Inside case Nine");
		case 1:
			System.out.println("Inside case One");
			break;
		default :
			System.out.println("Inside Default");
			break;
		case 2:
			System.out.println("Inside case two");
			break;
		case 3:
			System.out.println("Inside case three");
			break;
		
		
		}
	}

}
