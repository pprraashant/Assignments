package com.code.flowcontrol;

public class ForEachExample {
	
	public static void main(String p[])
	{
		int intArray [] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		int multipleResults=1;
		for(int value:intArray)
		{
			System.out.println("we are multipling "+multipleResults+ " with "+value);
			multipleResults=multipleResults+(multipleResults*value);
			if(value>10)
			break;
			
		}
		System.out.println("Sum Of sum multiplication "+multipleResults);
	}

}
