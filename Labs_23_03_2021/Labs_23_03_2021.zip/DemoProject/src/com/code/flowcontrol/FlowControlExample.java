package com.code.flowcontrol;

public class FlowControlExample {
	
	public static void main(String p[])
	{
		int a=2;
		
		if(!(a==0))
		{
		System.out.println("A value is "+a);	
		}
		else
		{
			System.out.println("In else part A value is "+a);	
		}
		
		/* if take only boolean type of argument
		 * if(!a) {
		 * 
		 * } else {
		 * 
		 * }
		 */
		
		if(a==0)
			System.out.println(a);
		System.out.println("outside the if "+a);
		
		if(a==0)
		{
			int b=a;
		}
		if(a==0);
		//	int b=a; declarative statement  without curly braces is not allowed
	}

}
