package com.code.flowcontrol;

public class DoWhileExample {
	
	public static void main(String [] ags)
	{
		int a=11;
		
		do
		{
			System.out.println("inside do while" + a++);
		}while(a<=15);
	}

}
