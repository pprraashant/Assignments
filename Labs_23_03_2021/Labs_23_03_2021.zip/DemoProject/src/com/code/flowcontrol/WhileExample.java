package com.code.flowcontrol;

public class WhileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boolean flag=false;
		int a=0;
		
		while(a<5)
		{
			a++;
			if(a==3)
				continue;
			System.out.println("inside While value of a "+a);
			
		}

	}

}
