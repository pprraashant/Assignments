package com.code.arrays;

public class ArrayExample {
	
	public static void main(String [] args)
	{
		int [] numbers= new int[] {1,2,3,4,5,6};
		
		String [] codes = new String [2];
		codes[0] ="Code0";
		codes[1] ="code1";
		System.out.println(numbers[4]);
		System.out.println(codes[1]);
		System.out.println(args[0]);
	}

}
