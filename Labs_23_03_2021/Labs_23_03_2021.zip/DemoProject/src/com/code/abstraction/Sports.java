package com.code.abstraction;

public class Sports extends LuxiorCar{

	@Override
	protected int speedUp(int x) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void changeType() {
		// TODO Auto-generated method stub
		
	}


}
