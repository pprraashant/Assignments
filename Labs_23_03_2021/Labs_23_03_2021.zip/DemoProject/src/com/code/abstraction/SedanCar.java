package com.code.abstraction;

public final class SedanCar extends Car{

	@Override
	protected int speedUp(int x) {
		
		return speed +x/2;
	}

	@Override
	public void changeType() {
		// TODO Auto-generated method stub
		
	}

}
