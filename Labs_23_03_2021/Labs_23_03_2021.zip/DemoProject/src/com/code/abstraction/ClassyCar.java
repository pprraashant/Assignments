package com.code.abstraction;

public class ClassyCar{
	

}
