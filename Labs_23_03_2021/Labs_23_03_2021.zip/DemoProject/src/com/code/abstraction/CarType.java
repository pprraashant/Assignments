package com.code.abstraction;

public interface CarType {
	
	String type= "";
	
	void changeType();
	void descope();

}
