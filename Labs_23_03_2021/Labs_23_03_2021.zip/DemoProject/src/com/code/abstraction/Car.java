package com.code.abstraction;

public abstract class Car implements CarType{
	
	int speed; 
	boolean isEngineOn;


	protected abstract int speedUp(int x);
	
	final protected int speedDown(int x)
	{
		return speed-x/2;
	}

	public void descope()
	{
		
	}


}
