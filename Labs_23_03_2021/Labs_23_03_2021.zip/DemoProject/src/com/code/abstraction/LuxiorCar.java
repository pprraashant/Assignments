package com.code.abstraction;

public abstract class LuxiorCar extends Car{
	
	int Ac; 
	
	int increaseAC(int x)
	{
		return x;
	}


}
