package com.code.abstraction;

public class UseAbstraction {
	
	public static void main(String []args)
	{
		//Car car1= new Car();
		Car car = new SedanCar();
		System.out.println(car.speedUp(5));
		
		car= new Sports();	
		System.out.println(car.speedUp(5));
	
	}

}
