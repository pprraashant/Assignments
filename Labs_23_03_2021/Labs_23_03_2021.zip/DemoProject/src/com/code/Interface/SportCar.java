package com.code.Interface;

public class SportCar implements Car , TypeOfEngine {
	
	String dualColor;

	@Override
	public int speedUp(int x) {
		
		return speed+x+5;
	}

	@Override
	public int speedDown(int x) {
		
		return speed-x+2;
	}

	@Override
	public void repair() {
		
		System.out.println(engineType+" is under repair");
		
	}
	 public int changeColor()
	 {
		 return color+123;
	 }


	
}
