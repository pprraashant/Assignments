package com.code.Interface;

public interface TypeOfEngine{
	
	String engineType="PETROL";
	
	void repair();

}
