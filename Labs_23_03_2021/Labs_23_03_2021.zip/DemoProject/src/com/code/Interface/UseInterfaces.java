package com.code.Interface;

/*
 * This class is for User Interface
 */

public class UseInterfaces {
	

	/*@Javadoc
	 * This class is for User Interface
	 */
	public void modifyCar(Car car)
	{
		System.out.println("Modifying car "+ car.name);
	}

	public static void main(String[] args) {

		Car car= new SportCar();

		System.out.println(car.speedUp(6));
		//car.repair();

		UseInterfaces ui= new UseInterfaces();
		ui.modifyCar(car);	

	}

}
