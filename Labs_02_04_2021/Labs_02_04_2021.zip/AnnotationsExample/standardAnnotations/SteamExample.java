package standardAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SteamExample {
	
	List<Integer> intd= Arrays.asList(1,2,3,4,5);
	List<Integer> newList = intd.stream().filter(number -> number <3).map(number -> number +3).collect(Collectors.toList());
			

}
