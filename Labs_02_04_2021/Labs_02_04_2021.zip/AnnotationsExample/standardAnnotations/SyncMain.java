package standardAnnotations;

public class SyncMain {

	public static synchronized void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		
		Thread t= new Thread();
		t.start();
		System.out.println("A");
		t.wait(1000);
		System.out.println("B");
	}

}
