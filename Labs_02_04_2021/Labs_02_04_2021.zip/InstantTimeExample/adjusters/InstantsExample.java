package adjusters;

import java.time.Duration;
import java.time.Instant;


public class InstantsExample {

	public static void main (String []a) throws InterruptedException
	{
		
		Instant start = Instant.now();
		Thread.sleep(2000);
		
		Instant end = Instant.now();
		Duration timeElapsed = Duration.between(start, end);
		long millis = timeElapsed.toMillis();
		long seconds = timeElapsed.getSeconds();
		System.out.println(millis);
		System.out.println("Seconds: "+seconds);
		System.out.println("Instant MIN: "+Instant.MIN);
		System.out.println("Instant EPOCH: "+Instant.EPOCH);
		//System.out.println("Instant EPOCH: "+Instant.parse("2021-01-01T10:15:30.00Z"));
		System.out.println("Instant MIN epoc Seconds: "+Instant.MIN.getEpochSecond());
		
		System.out.println("Instant MIN epoc Seconds: "+start.plus(Duration.ofDays(6)));
	}
}
