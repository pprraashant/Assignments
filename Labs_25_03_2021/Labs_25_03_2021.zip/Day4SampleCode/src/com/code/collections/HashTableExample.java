package com.code.collections;

import java.util.Hashtable;
import java.util.Map;

public class HashTableExample {
	
	public static void main(String[] args) {
		
		Map<String, String> hashtable= new Hashtable<>();
		
		hashtable.put("key", "value");
		hashtable.put("keys", "values");
		hashtable.put("keys01", "values01");
		System.out.println(hashtable);
		
		System.out.println(hashtable.get("keys01"));
	}

}
