package com.code.collections;

import java.util.*;

public class ArrayListDemo {
	public void arrlstdemo() {

		ArrayList<Integer> al = new ArrayList<>();
		//Map<String,String> a = new HashMap<String,String>();
		List<Integer> num = new ArrayList<>();
		
		/*
		 * ArrayList<Object> num1 = new ArrayList<>();
		 * 
		 * num1.add(1); num1.add("1"); System.out.println(num1); for (Object ob : num1)
		 * { System.out.println(ob); }
		 */
		num.add(10);
		num.add(9);
		num.add(8);
		num.add(7);
		num.add(5);
		
		//System.out.println(num);
		al.add(5);
		al.add(2);
		al.add(4);
		al.add(1);
		al.add(2, 3);
		al.addAll(num);

		Collections.sort(al);
		System.out.println("Sorted");
		System.out.println(al);
		System.out.println("revered");
		Collections.reverse(al);
		
		System.out.println(Collections.binarySearch(al, 5));

		System.out.println("Sorted and reverse");
		for (Integer ob : al) {
			System.out.println(ob);
		}

//		System.out.println(al.addAll(0, num));
//		System.out.println(al);
//		
//	
//		al.remove(2);
//		al.remove("4");
//
//		for (Object ob : al) {
//			System.out.println(ob);
//		}
		//System.out.println(al.get(3));
		//System.out.println(al.indexOf("3"));
		

	}
	public static void main(String [] args)
	{
		ArrayListDemo ak = new ArrayListDemo();
		ak.arrlstdemo();
	}

}

