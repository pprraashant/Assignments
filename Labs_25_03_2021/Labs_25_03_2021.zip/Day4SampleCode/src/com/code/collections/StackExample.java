package com.code.collections;

import java.util.Stack;

public class StackExample {
	
	
	
	public static void main(String[] args) {
		
		Stack<Float> strstack= new Stack<>();
		strstack.push(new Float(12.3));
		strstack.push(new Float(12.2));
		strstack.push(new Float(12.1));
		
		System.out.println(strstack);
		
		System.out.println(strstack.capacity());
		System.out.println(strstack.pop());
		System.out.println(strstack);
		System.out.println(strstack.peek());
		System.out.println(strstack);
	}

}
