package com.code.collections;

import java.util.*;
class LinkedHashsetExample{
	public static void main(String args[]){
		LinkedHashSet<String> al=new LinkedHashSet(); // creating linkedhashset
		                           // adding elements 
		al.add("Rick");
		al.add("Sam");
		al.add("Mariana"); 
		Iterator<String> itr=al.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
}
