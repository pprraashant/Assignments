package com.code.collections;

import java.util.ArrayList;

public class ArrayListWithUserObject {
	
	public static void main(String[] args) {
		
		ArrayList<Employee> employees= new ArrayList<>();
		
		Employee e1= new Employee("AS","YZ","A+","12-12-12",100000.00);
		Employee e2= new Employee("AB","YA","A+","13-12-12",100000.00);
		Employee e3= new Employee("AC","YB","A+","14-12-12",100000.00);
		Employee e4= new Employee("AD","YC","A+","15-12-12",100000.00);
		
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		
		System.out.println(employees);
	}

}
