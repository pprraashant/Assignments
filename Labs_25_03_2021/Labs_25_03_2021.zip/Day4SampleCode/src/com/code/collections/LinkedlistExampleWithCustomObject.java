package com.code.collections;
import java.util.*; 
public class LinkedlistExampleWithCustomObject{
	
	/*
	 * @Author - Prashant 
	 * Give example to LinkedList and its Operations.
	 * 
	 */
    public static void main(String args[]){
        LinkedList<Employee> linkedlist=new LinkedList<Employee>();// creating linked list 
       
        Employee e = new Employee("Abc","xyz","A+","12/12/12",202020);
        Employee e2 = new Employee("Abc2","xyz2","A+","12/12/10",202021);
        Employee e3 = new Employee("Abc3","xyz3","A+","12/12/11",2020200);
        
        linkedlist.add(e);
        linkedlist.add(e2);
        linkedlist.add(e3);
        
        Iterator<Employee> itr = linkedlist.iterator();
        while(itr.hasNext()){ 
            System.out.println(itr.next());
        }

    }
}