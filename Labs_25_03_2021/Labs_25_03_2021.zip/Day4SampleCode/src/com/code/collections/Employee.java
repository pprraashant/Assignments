package com.code.collections;


public class Employee {
	private String firstName,lastName,grade,joinDate;
	private double salary;
	private static int empid=0;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public static int getEmpid() {
		return empid;
	}
	public static void setEmpid(int empid) {
		Employee.empid = empid;
	}
	public Employee(String firstName, String lastName, String grade,
			String joinDate, double salary) {
		super();
		empid++;
		this.firstName = firstName;
		this.lastName = lastName;
		this.grade = grade;
		this.joinDate = joinDate;
		this.salary = salary;
	}
	
	public String toString()
	{
		System.out.println("FirstName "+this.firstName+" "+"LastName "+this.lastName+"Join Date "+ this.joinDate);
		return "";
	}
	

}

