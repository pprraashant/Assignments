package com.code.collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapExample {
	
	public static void main(String [] args)
	{
		Map<Integer,String> listOfUsers = new HashMap<>();
		String [] names = {"A","B","C","D","E"};
		for(int i=0;i<names.length;i++)
		{
		listOfUsers.put(i, names[i]);
		}
	
		System.out.println(listOfUsers.containsKey(41));
		listOfUsers.put(41, "G");
		
		 Set<Integer> keys=listOfUsers.keySet();
		 Collection values=listOfUsers.values();
		
		System.out.println(listOfUsers);
		System.out.println(keys);
		System.out.println(values);
		
			Set<Entry<Integer,String>> elements= listOfUsers.entrySet();
			
			for(Entry pair :elements)
			{
				System.out.println("Key ="+pair.getKey()+ " Value ="+pair.getValue());
			}
	}

}
