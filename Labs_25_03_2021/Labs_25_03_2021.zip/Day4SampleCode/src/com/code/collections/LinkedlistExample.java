package com.code.collections;
import java.util.*; 
public class LinkedlistExample{
	
	/*
	 * @Author - Prashant 
	 * Give example to LinkedList and its Operations.
	 * 
	 */
    public static void main(String args[]){
        LinkedList<Integer> linkedlist=new LinkedList<>();// creating linked list 
        linkedlist.add(100); // adding elements 
        linkedlist.add(99); 
        linkedlist.add(1010);
        linkedlist.add(101); 
        linkedlist.addFirst(101111); 
        Iterator<Integer> itr = linkedlist.iterator();
        while(itr.hasNext()){ 
            System.out.println(itr.next());
        }
        
        //linkedlist.clear();
        linkedlist.remove();
        System.out.println(linkedlist);
        System.out.println(linkedlist.isEmpty());
        
        LinkedList<Integer> copiedLinked=(LinkedList) linkedlist.clone();
        System.out.println(copiedLinked);
        System.out.println(copiedLinked.get(2));
    }
}