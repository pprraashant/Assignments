package com.code.collections;

import java.util.ArrayList;

public class ArrayListWIthCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "AST candidates";
		ArrayList<Character> characters = new ArrayList<>();
		
		char [] listOfchars = name.toCharArray();
		
		System.out.println(listOfchars);
		for(char a:listOfchars)
		{
			characters.add(a);
		}
		
		System.out.println(characters);
		
	}

}
