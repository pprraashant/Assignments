package com.code.collections;

import java.util.*;

class ArrayListExample {
	public static void main(String args[]) {

		ArrayList al = new ArrayList(); // creating array list
		al.add("Jack"); // adding elements
		al.add("Tyler");
		
		
		ArrayList<String> names= new ArrayList();
		names.addAll(al);
		names.add("Marina");
		names.add("Prashant");
		System.out.println("this Al content");
		Iterator itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("this names content");
		Iterator itrNames = names.iterator();
		while (itrNames.hasNext()) {
			System.out.println(itrNames.next());
		}
//		Iterator itrAnotherNames = names.iterator();
//		while(itrAnotherNames.hasNext())
//		{
//			String name=(String) itrAnotherNames.next();
//			if(!name.contains("Prashant"))
//				System.out.println("I am not on List");
//				
//		}
		if(!names.contains("Prashant"))
			System.out.println("I am not on List");
		names.remove("Jack");
		System.out.println("Is AL content present in Names "+ names.containsAll(al));
	}
}
