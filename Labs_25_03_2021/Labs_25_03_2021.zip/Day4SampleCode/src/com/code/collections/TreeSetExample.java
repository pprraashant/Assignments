package com.code.collections;

import java.util.*;

class TreeSetExample {
	public static void main(String args[]) {
		TreeSet<String> al = new TreeSet<String>(); // creating treeSet
		al.add("John"); // adding elements
		al.add("Sam");
		al.add("Rick");
		al.add("Rick");
		al.add("AAA");
		al.add("ZZZ");
		al.add("ZAA");
		al.add("ZAB");
		System.out.println("ceiling of Y "+al.ceiling("Y"));
		System.out.println("floor of L "+al.floor("L"));
		// al.remove("Rick");
		
		  Iterator<String> itr=al.iterator(); while(itr.hasNext()){
		  System.out.println(itr.next()); }
		 
	}
}