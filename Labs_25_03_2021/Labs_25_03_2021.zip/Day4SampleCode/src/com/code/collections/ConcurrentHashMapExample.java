package com.code.collections;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapExample {
	
	public static void main(String[] args) {
		
		ConcurrentHashMap<Integer, String> months= new ConcurrentHashMap<>();
	
		months.put(1, "Jan");
		months.put(11,"Nov");
		months.put(12, "Dec");
		
		System.out.println(months);
	}

}
