package com.code.collections;

import java.util.TreeMap;

public class TreeMapExample {
	
	public static void main(String[] args) {
		
		TreeMap<Double,String> doubletreeMap= new TreeMap<>();
		
		doubletreeMap.put(12.3, "twelePointThree");
		doubletreeMap.put(12.1, "twelePointOne");
		doubletreeMap.put(12.2, "twelePointTwo");
		doubletreeMap.put(12.4, "twelePointFour");
		
		System.out.println(doubletreeMap);
	
		
		
	}

}
