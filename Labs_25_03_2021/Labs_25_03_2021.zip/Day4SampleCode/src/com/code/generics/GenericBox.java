package com.code.generics;

public class GenericBox<T> {
	
	T t; 
	
	void setValue(T t)
	{
		this.t=t;
	}
	
	T getValue()
	{
		return t;
	}

}
