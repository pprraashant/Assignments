package com.code.generics;

public class UseTheBox {
	
	public static void main(String[] args) {
		
		
		/*
		 * Box [] boxes = new Box [10];
		 * 
		 * Box intBox = new Box(); intBox.setObject(12); boxes[0]=intBox;
		 * 
		 * Box stringBox= new Box(); stringBox.setObject("Twelve");
		 * 
		 * boxes[1]=stringBox;
		 * 
		 * System.out.println(boxes[0].getObject());
		 * System.out.println(boxes[1].getObject());
		 * 
		 * System.out.println(((Integer) boxes[0].getObject() +
		 * (Integer)boxes[1].getObject()));
		 */
		
		GenericBox [] genericBox = new GenericBox [10];
		
		GenericBox<Integer> intt= new GenericBox<>();
		intt.setValue(12);
		
		GenericBox<String> strings= new GenericBox<>();
		strings.setValue("Twelve");
		
		genericBox[0]=intt;
		genericBox[1]=strings;
		
		//Integer num = genericBox[1].getValue();
		
		
	} 

}
