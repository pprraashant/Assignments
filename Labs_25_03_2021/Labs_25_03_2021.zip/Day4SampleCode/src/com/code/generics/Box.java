package com.code.generics;

public class Box {
	
	Object object;
	
	void setObject(Object ob)
	{
		object=ob;
	}
	
	Object getObject()
	{
		return object;
	}

}
