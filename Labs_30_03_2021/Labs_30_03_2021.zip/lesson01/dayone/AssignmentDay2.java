package dayone;

public class AssignmentDay2 {
	
	/*
	 
	 
	 
	 1. Create List of 50 words in File Read the file
	  	 	apply the following opeations on to get details 
	  	 	like use tradition core java.
	  	 	1. Shortest words 
	  	 	2. count of Word's lengths greater than 5.
	  	 	3. Print words using method referance in upper cases.
	  	 	
	 2. use the method to find the usage of 
	 	summarizingInt, summarizingLong, summarizingDouble on steams 
	 	
	 3. Serialization - use same lab example of HR system. 
	 	serialize object with refer. and reterive them back. and 
	 	perform operations on it.
	 
	 4. Create functional Interface which will perform different arthimatic operations
	 		
	 		Interface Compute {
	 					
	 					operation(T a, T b);
	 		 	}
	  	 	Main 
	  	 	Add 
	  	 	Multiplication 
	  	 	Substractions
	  	 	Divide
	  	 	remainder
	 5. use above code the read the input from file 
	  		12 + 4
	  		12 * 4
	  		12 / 3 
	  	perform them using above functional interface (use lambda)
	  	
	  	File Path Files.lines()
	  	Steam<String>
	  	Collector.toList
	  	List<String> lines= 
	  	split whilespace 
	  	List<Operationhold>
	  	12 + 4
	  	for(int i
	  	
	  	class Operationhold 
	  		int opr1
	  		int o2
	  		String 
	  		int =sum 
	  	Interger.pareIne(ste)  
	 
	 6. write the results back into new file. 
	 		12 + 4 = 16 
	 		.
	 		.
	 		.
	 7. from assignment 3 store that file in Database;  	
	  
	 */

}
