package dayone;

public class AssigmentsDay1 {
	
	
	
	/*
	 * 
1. download zip -https://dev.mysql.com/downloads/mysql/
2. unzip in C:
3. set path variable of - C:\mysql-8.0.23-winx64\bin (bin path of mysql directory) (Environment variables)
Note : close the current cmd promot and open new 
4. start service mysqld 
	mysqld -install
	mysqld --init-file=C:\\mysql-init.txt -install
	content for mysql-init.txt
	ALTER USER 'root'@'localhost' IDENTIFIED BY 'password';
	mysqld -initialize
5. Go to services -> start Mysql service  parameter with ---init-file=C:\\mysql-init.txt
6. login with mysql -uroot -p 

	password is password which set in above file ie mysql-init.txt
	  Topics : 
		1. Database -MySql 
		2. Real time Object in Databases
		3. Funtional Intefeaces;
		4. Lambda Expression 
		5. method Refereance 
		6. Steams 
		
		Assigments 
		
		1. Install the connect to Mysql local server and print the tables from sys databases.
			
		2. Create one Bill class , 
		 	bill_id, date, FromDate , ToDate, BillAmount, typeOfBill, Duration 
		 	persist this Bill objects in databases; 
	  	3. Create List of 50 words in File Read the file
	  	 	apply the following opeations on to get details 
	  	 	like
	  	 	1. Shortest words 
	  	 	2. count of Word's lengths greater than 5.
	  	 	3. Print words using method referance in upper cases.
	  	 	
	  	4. Create class Records 
	  		id, time , duration , type (local, STD ) , rate. 
	  		
	  		add some dummy values. 
	  		
	  		use lambda expression to create comparator to compare and sort them using 
	  		each of below 
	  		Id, Duration , rate.  
	 
	 */

}
