package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamExample {
	
public static void main(String[] args) {
	
	List<String> words=  new ArrayList<>();
	
	words.add("ksdfasdf");
	words.add("uw");
	words.add("wewe");
	
//	int count = 0;
//	for (String w : words) {
//	    if (w.length() > 5) count++;
//	}
//	System.out.println(count);
	
//	System.out.println(words.stream().filter(w->w.length() >5).count());
	
	List<Integer> number = Arrays.asList(2,3,4,5);
	List<Integer> square = number.stream().map(x->x*x).collect(Collectors.toList());

	System.out.println(number);
	System.out.println(square);
	
	List<String> names = Arrays.asList("Reflection","Collection","Stream");
	List<String> result = names.stream().filter(s->s.startsWith("S")).collect(Collectors.toList());
	Set<String> setResult = names.stream().filter(s->s.startsWith("S")).collect(Collectors.toSet());
	List<String> sortedResult = names.stream().sorted().collect(Collectors.toList());

	System.out.println(names);
	System.out.println(result);
	System.out.println(setResult);
	System.out.println(sortedResult);

	List<Integer> nu = Arrays.asList(2,3,4,5);
	int even = nu.stream().filter(x->x%2==0).reduce(0,(ans,i)-> ans+i);
	System.out.println(even);
}

}
