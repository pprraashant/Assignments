package interfaces.innerclass;

@FunctionalInterface
interface DisplayMessage {
	
	void display();
	//void preetyDisplay(); not possible for lambda implementations
}

public class InnerClassAndLambdaExample {
	
	DisplayMessage dm= new DisplayMessage() {
		@Override
		public void display()
		{
			System.out.println("With Inner annonmous class");
		}
	};
	
	public static void main(String[] args) {
		
		InnerClassAndLambdaExample ms= new InnerClassAndLambdaExample();
		
		ms.dm.display();
		ms.displayMessage(()-> {System.out.println("Lambda Expression");});
		
		ms.displayMessage(()-> {System.out.println("Lambda Expression type 2");});
	}
	

	public void displayMessage ( DisplayMessage dm)
	{
		dm.display();
	}

}
