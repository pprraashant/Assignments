package interfaces;

import java.util.Arrays;
import java.util.Comparator;
import java.util.logging.Logger;

import javax.swing.Timer;

public class EmployeeSortTestLambda {
	public static void main(String[] args) {
		Employee[] staff = new Employee[3];

		staff[0] = new Employee("Harry Hacker", 75000);
		staff[1] = new Employee("Carl Cracker", 75000);
		staff[2] = new Employee("Tony Tester", 38000);
		
		Arrays.sort(staff,(first , second) -> first.getName().compareTo(second.getName()));
		
		Arrays.sort(staff,(first , second) -> first.getSalary().compareTo(second.getSalary()));
		System.out.println(Arrays.toString(staff));
		System.out.println();
		//Arrays.sort(staff,(first , second) -> first.getEmpId().compareTo(second.getEmpId()));
		
		Arrays.sort(staff,(first , second) ->  {
			 if(first.getEmpId() == second.getEmpId())
				 return 0; 
			 else if(first.getEmpId() > second.getEmpId()) 
				 return 1;
			  return -1;
		});

		System.out.println(Arrays.toString(staff));
		
	}
}