package interfaces;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Logger;

import javax.swing.Timer;

public class EmployeeSortTestMethodRef {
	public static void main(String[] args) {
		List<Employee> staff = new ArrayList<Employee>();

		staff.add(new Employee("Harry Hacker", 75000));
		staff.add(new Employee("Carl Cracker", 75000));
		staff.add(new Employee("Tony Tester", 38000));
		
		Collections.sort(staff,(first , second) -> first.getName().compareTo(second.getName()));

		//System.out.println(staff.toString());
		//System.out.println("");
		//staff.forEach(e -> System.out.println(e));
		System.out.println("");
		staff.forEach(System.out::println);
		
	}
}