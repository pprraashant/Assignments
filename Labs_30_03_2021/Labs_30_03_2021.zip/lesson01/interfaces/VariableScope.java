package interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

public class VariableScope {
	
	public static void repeatMessage(String text, int delay) {
		List<Employee> staff = new ArrayList<Employee>();
		staff.add(new Employee("Harry Hacker", 75000));
		staff.add(new Employee("Carl Cracker", 75000));
		staff.add(new Employee("Tony Tester", 38000));
		for (int i = 1; i <= 5; i++) {
		staff.forEach(e -> {
			int j=0;
			System.out.println( text);
			System.out.println (e.getName());
			//System.out.println (i);
			System.out.println (j++);
		});
		}
		System.out.println("inside and at the end of repeatMessage");
	}
	public static void repeat(int n, Runnable action) {
	    for (int i = 0; i < n; i++) action.run();
	}
	
	public static void repeat(int n, IntConsumer action) {
	    for (int i = 0; i < n; i++) action.accept(i);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//repeatMessage("Hello", 1000); // Prints Hello every 1,000 milliseconds
		repeat(5, () -> System.out.println("Hello, World!"));
		//repeat(2, () -> repeatMessage("HelloRepeat",1000));
		//repeat(10, i -> System.out.println("Countdown: " + (9 - i)));
System.out.println("End of Main");
	}

}
