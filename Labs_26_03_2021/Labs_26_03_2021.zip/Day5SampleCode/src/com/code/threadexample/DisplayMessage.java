package com.code.threadexample;

public class DisplayMessage extends Thread {
	   private String message;
	   
	   public DisplayMessage(String message) {
	      this.message = message;
	   }
	   
	   public void run() {
		   int n=0;
	      while(true) {
	         System.out.println(message);
	         if(n++==500)
	        	 break;
	         try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	         if(this.getName().contains("hello"))
	         Thread.yield();
	      }
	   }
	}
