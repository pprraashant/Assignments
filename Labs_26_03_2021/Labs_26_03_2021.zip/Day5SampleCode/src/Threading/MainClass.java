package Threading;

public class MainClass {
	public static void main(String[] args) {
		new Child();
		for(int i=5;i>0;i--)
		{
			System.out.println("Main Thread " + i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Main Thread Interrupted");
			}
		}
		System.out.println("Main Thread Exiting");
	}

}
