package Threading;

public class Child implements Runnable {
	Thread t;
	Child(){
		t = new Thread(this,"Child");
		t.start();
	}
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=5;i>0;i--)
		{
			System.out.println("Child Thread "+i);
			try {
				t.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Child Thread Interrupted");
			}
		}
		System.out.println("Child Thread Exiting");	
		
	}
	

}
