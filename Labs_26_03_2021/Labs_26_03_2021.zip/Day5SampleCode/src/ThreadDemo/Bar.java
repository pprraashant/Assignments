package ThreadDemo;
public class Bar implements Runnable {
 
    @Override
    public void run() {
        objectLock();
    }
     
    public void objectLock() {
        System.out.println(Thread.currentThread().getName());
        synchronized(Bar.class) {
            System.out.println("synchronized block " + Thread.currentThread().getName());
            System.out.println("synchronized block " + Thread.currentThread().getName() + " end");
        }
    }
 
    public static void main(String[] args) {
        Bar b1 = new Bar();
        Thread t1 = new Thread(b1);
        Thread t2 = new Thread(b1);
         
        Bar b2 = new Bar();
        Thread t3 = new Thread(b2);
         
        t1.setName("t1");
        t2.setName("t2");
        t3.setName("t3");
         
        t1.start();
        t2.start();
        t3.start();
    }
    
    
    /*Note that the thread t3 will not block 
    when threads t1 and t2 block. This is because the
    lock has been placed on �this� object and thread t3
    has different �this� object than threads t1 or t2.*/

 
 }


 