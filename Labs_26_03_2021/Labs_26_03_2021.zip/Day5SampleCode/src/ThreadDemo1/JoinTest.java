package ThreadDemo1;

class A1 extends Thread {
	B1 b;

	A1(B1 b1) {
		b = b1;
	}

	public void run() {
		for (int i = 0; i < 50; i++) {
			System.out.print("A: " + i);
			try {
				Thread.sleep(100);
			} catch (Exception e) {
			}
			if (i == 20)
				try {
					b.join();
				} catch (Exception e) {
				}
		}
	}
}

class B1 extends Thread {
	A1 a1;
	
	B1(A1 a)
	{
		a1=a;
	}
	public void run() {

		for (int i = 0; i < 50; i++) {
			System.out.println("  B: " + i);
			try {
				Thread.sleep(100);
			} catch (Exception e) {
			}
			if(i==48)
			{
				try {
					a1.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
	}
}

class JoinTest {
	public static void main(String arg[]) {

		B1 b1 = null;

		A1 a1 = new A1(b1);
		b1 = new B1(a1);

		b1.start();
		a1.start();

	}
}