package ThreadDemo1;

class TwoStringsOperation {
static synchronized void print(String str1, String str2) {
 System.out.print(str1);
 try {
 Thread.sleep(500);
 } catch (InterruptedException ie) {
 }
 System.out.println(str2);
 }
 }
class PrintStringsThreadIn implements Runnable {
 Thread thread;
 String str1, str2;
 PrintStringsThreadIn(String str1, String str2) {
 this.str1 = str1;
 this.str2 = str2;
 thread = new Thread(this);
 thread.start();
 }
 public void run() {
 TwoStringsOperation.print(str1, str2);
 }
 }
class UnSyn {
 public static void main(String args[]) {
 new PrintStringsThreadIn("Hello ", "there.");
 new PrintStringsThreadIn("How are ", "you?");
 new PrintStringsThreadIn("Thank you ","very much!");
 }
 }