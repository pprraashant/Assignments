package ThreadDemo1;

class TwoStrings1 {
	static void print(String str1, String str2) {
		System.out.print(str1);
		try {
			Thread.sleep(500);
		} catch (InterruptedException ie) {
		}
		System.out.println(str2);
	}
}
class PrintStringsThread11 implements Runnable {
	Thread thread;
	String str1, str2;
	TwoStrings1 ts;
	PrintStringsThread11(String str1, String str2,TwoStrings1 ts) {
		this.str1 = str1;
		this.str2 = str2;
		this.ts=ts;
		thread = new Thread(this);
		thread.start();
	}
	public void run() {
		synchronized(ts){
			print(str1, str2);
		}
	}
	static synchronized void print(String str1, String str2) {
		 System.out.print(str1);
		 try {
		 Thread.sleep(500);
		 } catch (InterruptedException ie) {
		 }
		 System.out.println(str2);
		 }
}
class TestThread {
	public static void main(String args[]) {
		new PrintStringsThreadIn("Hello ", "there.");
		new PrintStringsThreadIn("How are ", "you?");
		new PrintStringsThreadIn("Thank you ","very much!");
	}
}