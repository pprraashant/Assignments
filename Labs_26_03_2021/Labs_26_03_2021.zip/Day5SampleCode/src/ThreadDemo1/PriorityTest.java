package ThreadDemo1;

public class PriorityTest {

  public static void main(String[] args) {
    PriorityTest t = new PriorityTest();
  }

  public PriorityTest() {
    Runnable runner = new MyRunnable("First");
    Thread t = new Thread(runner);
    t.setPriority(Thread.MIN_PRIORITY);
    t.start();
    System.out.println("Priority"+t.getPriority());
    runner = new MyRunnable("Second");
    t = new Thread(runner);
    t.setPriority(Thread.MAX_PRIORITY);
    t.start();
    System.out.println("Priority"+t.getPriority());
  }

  class MyRunnable implements Runnable {

    protected String name;

    public MyRunnable(String tn) {
      name = tn;
    }

    public void run() {
		int i=0;
      while (i++<100) {
        System.out.println(name);
      }
    }
  }

}