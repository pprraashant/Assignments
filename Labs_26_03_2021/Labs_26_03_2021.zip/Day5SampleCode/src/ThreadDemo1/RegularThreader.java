package ThreadDemo1;

class HelloThread extends Thread   
{   
  public void run()   
  {   
    for ( ; ; )   
    {   
      System.out.println("hello"); try{  
      sleep(1000);   }catch(Exception e){e.printStackTrace();}
    }   
  }   
}   
public class RegularThreader   
{   
  public static void main(String[] args)   
  {   
    Thread hello = new HelloThread();   
    hello.start();   
    System.out.println("Sorry, I must be leaving");   
  }   
} 
class DaemonThreader   
{   
  public static void main(String[] args)   
  {   
    Thread hello = new HelloThread();   
    hello.setDaemon(true);   
    hello.start();   
    System.out.println("Sorry, I must be leaving");   
  }   
}