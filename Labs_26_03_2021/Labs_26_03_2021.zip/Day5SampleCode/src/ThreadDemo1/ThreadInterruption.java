package ThreadDemo1;

class A extends Thread
{
	public void run(){
		for(int i=0;i<10;i++){
		try{
			Thread.sleep(10000);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("finished");
		}
	}
}
class B extends Thread
{
	A a1;
	B(A temp){
		a1=temp;
	}
	public void run(){
		try{
			Thread.sleep(5000);
			a1.interrupt();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
class  ThreadInterruption
{
	public static void main(String[] args) 
	{
		A a1=new A();
		B b1=new B(a1);
		a1.start();
		b1.start();
	}
}
