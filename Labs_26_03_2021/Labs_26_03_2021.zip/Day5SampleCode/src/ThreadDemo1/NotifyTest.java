package ThreadDemo1;

class First {
	int id;
}

class Second extends Thread {
	First first;

	public Second(First f) {
		first = f;
	}

	public void run() {
		synchronized (first) {
			System.out.println(getName() + " Waiting");
			try {
				first.wait(0);
			} catch (Exception e) {
			}
			System.out.println(getName() + " Finished Waiting");
		}
	}
}

class Third extends Thread {
	First first;

	Third(First f) {
		first = f;
	}

	public void run() {
		synchronized (first) {
			System.out.println(getName() + " Doing buisness ");
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
			}

			first.notifyAll();
		}
	}
}

class NotifyTest {
	public static void main(String arg[]) {
		First f = new First();
		Second s = new Second(f);
		Third t = new Third(f);
		s.setName("second");
		t.setName("third");
		s.start();
		t.start();
	}
}