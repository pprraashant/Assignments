package ThreadDemo1;

class MainThread{
	public static void main(String args[]){
		Thread thread = Thread.currentThread();
		System.out.println("Main thread is named \"" + thread.getName()+"\"");
		
		System.out.println("Main thread priority\"" + thread.getPriority()+"\"");
		System.out.println("Main thread active count" + thread.activeCount()+"\"");
	}
}
