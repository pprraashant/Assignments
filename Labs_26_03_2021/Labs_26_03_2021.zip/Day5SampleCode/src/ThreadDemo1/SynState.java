package ThreadDemo1;

class TwoStrings2 {
 static void print(String str1, String str2) {
 System.out.print(str1);
 try {
 Thread.sleep(500);
 } catch (InterruptedException ie) {
 }
 System.out.println(str2);
 }
 }
class PrintStringsThread2 implements Runnable {
 Thread thread;
 String str1, str2;
 TwoStringsOperation ts;
 PrintStringsThread2(String str1, String str2) {
 this.str1 = str1;
 this.str2 = str2;
 thread = new Thread(this);
 thread.start();
 }
 public void run() {
 synchronized(ts) {
ts.print(str1, str2);
 }

 }
 }
class SynState {
 public static void main(String args[]) {
 TwoStringsOperation ts = new TwoStringsOperation();
 new PrintStringsThreadIn("Hello ", "there.");
 new PrintStringsThreadIn("How are ", "you?");
 new PrintStringsThreadIn("Thank you ","very much!");
 }
 }