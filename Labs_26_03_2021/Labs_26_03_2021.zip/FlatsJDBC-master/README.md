# FlatsJDBC
## 1. Description
#### Project is a demo of usage Java core libraries and low level data source with JDBC technology for connecting to MySQL database.
## 2. Technologies
- Java 7
- Maven 3.6.0
- MySQL DB 8.0
- JDBC
- SQL
- CRUD operations
- Console user interface
- Exception handling
- Configuration through property file (using Property class)
## 3. Author
#### [Serhii Yatchenko](https://github.com/Psyh2409/FlatsJDBC)
#### [E-mail](psyh2409@gmail.com)
