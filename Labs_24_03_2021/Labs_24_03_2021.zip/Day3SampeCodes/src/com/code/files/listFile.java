package com.code.files;

	import java.io.File;

	class listFile {
	  public static void main(String[] args) {

	    // creates a file object
		  String path = System.getProperty("user.dir");
		  System.out.println(path);
	    File file = new File(path);

	    // returns an array of all files
	    String[] fileList = file.list();
	   

	    for(String str : fileList) {
	     // System.out.println(str);
	    }
	    
	    File [] listOfFiles= file.listFiles();
	    
	    for(File fileFromList:listOfFiles)
	    {
	    	System.out.println("\""+fileFromList.getName()+"\""+" is execuatable "
	    +fileFromList.canExecute()+ " length of file "
	    + fileFromList.length()+" is Directory "
	    + fileFromList.isDirectory());
	    }
	  }
	}