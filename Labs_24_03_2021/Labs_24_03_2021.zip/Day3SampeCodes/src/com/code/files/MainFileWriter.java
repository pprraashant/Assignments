package com.code.files;
import java.io.FileWriter;
import java.io.IOException;


public class MainFileWriter {
	// importing the FileWriter class

	   public static void main(String args[]) throws IOException {

	     String data = "This is the data in the output file";
	     FileWriter output=null;
	     try {
	       // Creates a Writer using FileWriter
	       output = new FileWriter("output.txt");

	      
	       // Writes string to the file
	       output.append(data);
	       System.out.println("Data is written to the file.");

	       
	     }
	     catch (Exception e) {
	       e.getStackTrace();
	     }
	     finally
	     {
	    	// Closes the writer
		       output.close();
	     }
	  }
	}
