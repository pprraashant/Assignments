package com.code.files;

	import java.io.File;

	class Mkdires {
	  public static void main(String[] args) {

	    // creates a file object in the current path
	    File file = new File("Java Tutorial01\\directory01");

	    // tries to create a new directory
	    boolean value = file.mkdirs();
	    if(value) {
	      System.out.println("The new directory is created.");
	    }
	    else {
	      System.out.println("The directory already exists.");
	    }
	  }
	}
