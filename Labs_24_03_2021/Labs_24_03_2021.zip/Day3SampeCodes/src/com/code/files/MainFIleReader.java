package com.code.files;

//importing the FileReader class
import java.io.FileReader;
import java.io.IOException;

class MainFIleReader {
public static void main(String[] args) throws IOException {

 char[] array = new char[100];
 FileReader input = null;
 try {
   // Creates a reader using the FileReader
    input= new FileReader("input.txt");

   // Reads characters
   input.read(array);
   System.out.println("Data in the file:");
   System.out.println(array);

  
 }
 catch(Exception e) {
   e.getStackTrace();
 }
 finally
 {
	 // Closes the reader
	   input.close();
 }
}
}
