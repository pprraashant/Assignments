package com.code.files;

import java.io.File;

class FileDelete {
  public static void main(String[] args) {

    // creates a file object
    File file = new File("newFile24032021.txt");

    // deletes the file
    boolean value = file.delete();
    if(value) {
      System.out.println("The File is deleted.");
    }
    else {
      System.out.println("The File is not deleted.");
    }
  }
}
