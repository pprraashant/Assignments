package com.code.files;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class CopyFile {
  public static void main(String[] args) throws Throwable {

    byte[] array = new byte[5];
    FileInputStream sourceFile=null;
    FileOutputStream destFile=null;
    try {
      sourceFile = new FileInputStream("input.txt");
      destFile = new FileOutputStream("newFile");

      // reads all data from input.txt
      sourceFile.read(array);

      // writes all data to newFile
      destFile.write(array);
      System.out.println("The input.txt file is copied to newFile.");

    }
    catch (Exception e) {
      e.getStackTrace();
    }
    finally
    {
    	   // closes the stream
        sourceFile.close();
        destFile.close();
    }
  }
}
