package com.code.Interface;

public interface Car{
	
	int speed=0;
	int gear=0;
	int color=0;
	String name = "IamCar";
	public int speedUp(int x);
	public int speedDown(int x);
	//Java 8 default method
	default public void xyz() 
	{
		
	}
}
