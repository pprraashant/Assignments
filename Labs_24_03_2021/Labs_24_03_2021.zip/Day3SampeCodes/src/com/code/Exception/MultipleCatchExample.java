package com.code.Exception;

public class MultipleCatchExample {

	public static void main(String[] args) {

		try {
			int a[] = new int[5];
			a[3] = 30 / 1;
			throw new RuntimeException();
		} catch (ArithmeticException e) {
			System.out.println("Arithmetic Exception occurs" + e);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBounds Exception occurs" + e);
		} catch (Exception e) {
			System.out.println("Parent Exception occurs" + e);
		}

		System.out.println("rest of the code");
	}
}
