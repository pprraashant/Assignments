package com.code.Exception;

public class ArrayException {  
	  
    public static void main(String[] args) {  
    	int[]  arr= {1,3,5,7}; 
        try  
        {  
       
        System.out.println(arr[1]); //may throw exception  
        System.out.println("I am after Exception point I am dependent on line 10");
        }  
            // handling the array exception  
        catch(ArrayIndexOutOfBoundsException e)  
        {  
        	//System.out.println(e);
            e.printStackTrace();  
            System.out.println("program is handled ArrayIndexOutOfBoundException"); 
        }
        finally 
        {
        	System.out.println("I am in finally.Always executed");
        }
        System.out.println("rest of the code "+arr[3]);  
    }  
      
}  
