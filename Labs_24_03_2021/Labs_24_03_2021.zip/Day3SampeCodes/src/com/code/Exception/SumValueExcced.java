package com.code.Exception;

@SuppressWarnings("serial")
public class SumValueExcced extends Exception {
	
	public SumValueExcced(String msg)
	{
	super(msg);
	}

}
