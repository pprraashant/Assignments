package com.code.Exception;

import java.util.Scanner;

public final class Test {
	
	public int sum(int [] arr) throws SumValueExcced 
	{
		int sum=0;
		for(int b:arr)
		{
			sum+=b;
		}
		if(sum>20) 
			throw new SumValueExcced("Sum is greater than 20");
		return sum;
	}

	public static void main(String[] args){
		
		Scanner in = new Scanner(System.in); 
        //int s = in.nextInt();
		
		int [] a= {1,2,3,4,5,6};
		System.out.println("I am here");
		Test t= new Test();
		
		
			try {
				System.out.println(t.sum(a));
			} catch (SumValueExcced e) {
				// TODO Auto-generated catch block
				System.out.println("Sum is greater than 20");
			}
			System.out.println("End of main");
	}
}
