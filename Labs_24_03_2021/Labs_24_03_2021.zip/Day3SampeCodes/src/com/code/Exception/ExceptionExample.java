package com.code.Exception;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ExceptionExample {
	
	public static void main(String[] args){
		
		
		try
		{
			BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		System.out.println(args[0]);
		Thread.sleep(20);
		
		int a = Integer.parseInt(br.readLine());
		System.out.println(12/a);
		br.close();
		br.readLine();
		System.out.println("End of try monitoring");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("No argument supplied");
			//e.printStackTrace();
		}
		catch(InterruptedException  e)
		{
			System.out.println("interrupted");
			//e.printStackTrace();
		}
		catch(IOException e)
		{
			System.out.println("Io Exception br is closed");
		}
		catch(ArithmeticException e)
		{
			System.out.println("Input is incorrect which cause arithmetic Exception");
		}

		catch(Exception e)
		{
			System.out.println("Parent Exception as no matching exception found");
		}
		catch(Throwable e)
		{
			System.out.println("Parent of parent Exception as no matching exception found");
		}
		finally
		{
			System.out.println("finally block which always going executes");
		}
		System.out.println("End of main method");
	}

}
