package com.code.Exception;

import java.util.Scanner;

public class TryCatchExample2 {
	
	  
    public static void main(String[] args) {  
    	
    	Scanner in = new Scanner(System.in); 
        int s = in.nextInt();
        if(s<=0)
        	throw new RuntimeException();
        try  
        {  
        int data=50/s; //may throw exception   
        }  
            //handling the exception  
        catch(ArithmeticException e)  
        {  
            System.out.println("Invalid Input please provide value greater than 0");  
        }  
        System.out.println("rest of the code");  
    }  
      
}
