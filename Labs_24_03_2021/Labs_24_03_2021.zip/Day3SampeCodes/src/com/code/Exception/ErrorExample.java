package com.code.Exception;

public class ErrorExample {
	
	public static void main(String[] args) {
		
		System.out.println("Inside Main");
		print();//java.lang.StackOverflowError
	}
	
	public static void print() {
		
		main(new String [] {"Prashant"});//java.lang.StackOverflowError
		System.out.println("Inside print");
	}

}
