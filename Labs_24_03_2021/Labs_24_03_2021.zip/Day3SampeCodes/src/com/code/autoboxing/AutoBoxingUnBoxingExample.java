package com.code.autoboxing;

public class AutoBoxingUnBoxingExample {
	
	public static void main(String[] args) {
		
		int a=10;
		Integer b=a; //autoboxing
		int c=b; // unboxing 
		
		System.out.println(a +" "+ b +" "+c);
		
		int d= Integer.parseInt("23");
		
	
		
		System.out.println(d);
	}

}
