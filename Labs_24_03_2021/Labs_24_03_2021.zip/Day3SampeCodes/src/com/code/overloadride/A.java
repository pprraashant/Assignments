package com.code.overloadride;


public abstract class A {
	
	int x;
	int y;
	
	A()
	{
		System.out.println("in Default constructor of class A");
	}
	
	A(int a, int b)
	{
		x=a;
		y=b;
		System.out.println("Parameterimzed constructor of class A");
	}
	
	public void print()
	{
		System.out.println("Display in A "+x+" "+y);
	}
	public final void print(int times) //method overloading
	{
		for(int i=0;i<times;i++)
		System.out.println("Display in A print for "+i+"times"+x+" "+y);
	}

}
