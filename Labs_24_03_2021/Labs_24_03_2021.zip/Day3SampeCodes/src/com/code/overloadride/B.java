package com.code.overloadride;

public final class B extends A{
	
	int num;
	
	B()
	{
		System.out.println("in Default constructor of class B");
	}
	
	B(int a)
	{
		num=a;
		System.out.println("Parameterimzed constructor of class B");
	}
	
	public void print()
	{
		System.out.println("Display in B "+x+" "+y+" "+num);
	}
	
	/*
	 * public void print(int times) // can't be override { for(int i=0;i<times;i++)
	 * System.out.println("Display in B print for "+i+"times"+x+" "+y); }
	 */

	
}
