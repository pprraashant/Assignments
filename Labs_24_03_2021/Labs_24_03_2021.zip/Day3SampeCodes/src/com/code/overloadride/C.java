package com.code.overloadride;

public class C //extends B{  //can't subclassed
{
}
