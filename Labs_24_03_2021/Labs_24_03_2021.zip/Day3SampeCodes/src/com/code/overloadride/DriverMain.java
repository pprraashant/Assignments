package com.code.overloadride;

public class DriverMain {
	
	public static void main(String[] args) {
		
		//A a = new A();
		//A a1 = new A(2,3);
		B b = new B();
		B b1 = new B(2);
		
		//System.out.println(a.x);
		System.out.println(b.x);
		//a.print();
		b.print();
	}

}
