package com.code.abtractclass;

public abstract class AirIndia {
	
	int amount;
	
	abstract int calculateAmount(String ticket);
	
	 void book()
	{
	 System.out.println("Booking is handled by AirIndia");
	}

}
