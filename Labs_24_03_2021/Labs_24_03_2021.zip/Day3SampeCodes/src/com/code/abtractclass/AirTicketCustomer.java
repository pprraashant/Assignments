package com.code.abtractclass;

public class AirTicketCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// AirIndia airIndia= new AirIndia(); object creation is not possible from abstract class only ref can created
		AirIndia am= new AmazonAirTicketApp();
		am.book();
		System.out.println(am.calculateAmount("Pune to Mumbai"));

	}

}
