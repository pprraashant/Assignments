package com.code.string;

public class StringBuilderExample {
	
	public static void main(String[] args) {
		
		StringBuilder strbuild = new StringBuilder();
		
		strbuild.append("Hello");
		strbuild.append("World");
		
		String str=strbuild.toString();
		System.out.println(strbuild);
	}

}
