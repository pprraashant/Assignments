package com.code.string;

public class StringBufferExample {

	public static void main(String[] args) {
		
		StringBuffer sbf= new StringBuffer();
		
		sbf.append("THis is java course");
		sbf.append("new");
		System.out.println(sbf);
		String str = sbf.substring(0,19).toUpperCase().toString();
		System.out.println(str);
	}
}
