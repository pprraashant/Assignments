package com.code.string;

public class StringExample {
	
	public static void main(String[] args) {
		
		String str= "Hello Java!";
		String str1 = new String("Hello Java! first");
		//String str1 = "Hello Java! first";
		String str3 = "Hello Java! first";
		
		//str3= str3+str1;
		if(str1.equals(str3))
			System.out.println("equals");
		else
			System.out.println("not equals");
		
		if(str1==str3)
			System.out.println("equals");
		else
			System.out.println("not equals");
		
		System.out.println(str3);
		System.out.println(str.charAt(3));
		System.out.println(str.indexOf('l'));
		
	}

}
