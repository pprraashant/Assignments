package fooddemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class HelloWorldApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext appContextUsingClassPath = new ClassPathXmlApplicationContext("myTestPackage/HelloWorldapplication.xml");
		
		HelloWorld helloWorld= appContextUsingClassPath.getBean("HelloWorld1",HelloWorld.class);
		
		HelloWorld helloWorld2= appContextUsingClassPath.getBean("HelloWorld1",HelloWorld.class);
		
		System.out.println(helloWorld.getMsg());
		System.out.println(helloWorld2.getMsg());
		

	}

}
