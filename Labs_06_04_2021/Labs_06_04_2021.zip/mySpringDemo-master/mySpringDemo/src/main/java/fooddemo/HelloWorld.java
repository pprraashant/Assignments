package fooddemo;

public class HelloWorld {
	
	String msg;
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	HelloWorld()
	{
		System.out.println("Default Contructor in HelloWorld");
	}
	
	HelloWorld(String message)
	{
		System.out.println("I am in Hello World Construtor");
		this.msg=message;
		System.out.println("Parameterized Contructor in HelloWorld");
	}
	

}
