package com.code.regularexpression;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression {

	public static void main(String p[]) {

//		String str =" *Jjava ava";
//		
//		String [] token=str.split("j*");
//		
//		Pattern pt = Pattern.compile("j*");
//		Matcher match = pt.matcher(str);
//		while (match.find()) {
//		    System.out.println(match.group());
//		}
//		System.out.println("tokens");
//		for(String s: token)
//		{
//			System.out.println(s);
//		}
		String input = "9:45am";
		Matcher matcher = Pattern.compile("[0-9]+").matcher(input);

		while (matcher.find())
			System.out.println(matcher.group());

		int processors = Runtime.getRuntime().availableProcessors();
		System.out.println(processors);

	}

}
