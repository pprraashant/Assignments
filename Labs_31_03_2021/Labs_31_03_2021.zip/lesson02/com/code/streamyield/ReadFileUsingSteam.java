package com.code.streamyield;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.IntSummaryStatistics;
import java.util.Iterator;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class ReadFileUsingSteam {

	public static void main(String [] args) throws IOException
	{
		
		
		//Path path = Paths.get("C:\\Users\\pawarp\\Videos\\PP\\Trainings\\Java\\Coroprate Java Traning\\corejava-advanced-code\\corejava-advanced-code\\lesson02","cities.txt");
		Path java = Paths.get("Java");
		Path cdriver =Paths.get("C:\\");
		Path filecities=cdriver.resolveSibling("cities.txt");
//		filecities.resolve(java);
//		System.out.println(filecities.getNameCount());
//		System.out.println(filecities.subpath(1, filecities.getNameCount()).toUri());
//		Iterator<Path> folders= filecities.iterator();
//		while(folders.hasNext())
//		{
//			System.out.println(folders.next().toUri());
//		}
		//Path path = Paths.get("C:\\..\\","\\lesson02","cities.txt");
		try (Stream<String> lines = Files.lines(filecities)) {
		   
			//System.out.print(lines.count());
			Stream<String> longWords = lines
					.filter(w -> w.length() > 20)
					.peek(e -> System.out.println("Fetching " + e))
					.limit(5);
			Stream<String> upperCare = longWords.distinct().map(String::toUpperCase);
			Stream<String> longestFirst =
					upperCare.sorted(Comparator.comparing(String::length).reversed());
			
			IntSummaryStatistics summary=longestFirst.collect(Collectors.summarizingInt(String::length));
			System.out.println(summary);
			String longestColString = longestFirst.collect(Collectors.joining(","));
			System.out.println(longestColString);
			System.out.println(longestFirst.findFirst().orElse("I am Empty"));
			Optional<String> max = longestFirst.max(String::compareToIgnoreCase);

			longestFirst.forEach(System.out::println);
		
		}

	}
}
