package streamExample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class SteamExample {
	
	public static void main(String [] args)
	{
		
	
		Stream<String> names = Stream.of("merrily", "merrily", "merrily", "gently");
		
		//names.forEach(System.out::println); //java.lang.IllegalStateException: stream has already been operated upon or closed
		
		Stream<String> uniqueWords= names.distinct();
	
	    // Only one "merrily" is retaine
	
		Predicate<String> pre;
		
		uniqueWords.forEach(System.out::println);
//		
//		String sentence = "\uD835\uDD46 is the set of octonions.";
//		IntStream codes = sentence.codePoints();
//		codes.forEach(System.out::println);
//		//System.out.println(codes.peek(System.out::println));
//		
//		int[] shortWords = new int[12];
//		words.parallelStream().forEach(
//		    s -> { if (s.length() < 12) shortWords[s.length()]++; });
//		    // Error�race condition!
//		System.out.println(Arrays.toString(shortWords));
		
//		Map<Integer, Long> shortWordCounts =
//				words.parallelStream()
//				    .filter(s -> s.length() < 12)
//						.collect(groupingBy(String::length, counting()));


	}

}
