package streamExample;

import java.util.regex.Pattern;
import java.util.stream.Stream;

public class PatternStream {
	
	public static void main(String[] args) {
		
		String contents = "This is example of Adanvce Java Java simple code for pattern with stream";
		Pattern pattern = Pattern.compile("\\s+"); // Break at white space 
		Stream<String> words = pattern.splitAsStream(contents);
		
		words.limit(7).skip(5).peek(System.out::println).distinct().forEach(System.out::println);
		
		Object[] powers = Stream.iterate(1.0, p -> p * 2)
			    .peek(e -> System.out.println("Fetching " + e))
			    .toArray();


	}

}
