package com.code.carmvc.view;

public class CarView {
	
	public void printCarDetails(int year,String make, int speed) 
	{ 
		System.out.println("Year: "+year); 
		System.out.println("Make: " + make); 
		System.out.println("Speed: " + speed); 
	} 

}
