package com.code.controller;

import com.code.carmvc.model.Car;
import com.code.carmvc.view.CarView;

public class CarController {
	
	Car car;
	CarView carView;
	
	public CarController(Car car,CarView carView)
	{
		this.car=car;
		this.carView=carView;
	}
	
	public void setCarMake(String y)
	{
		car.setMake(y);
	}
	
	public void setCarYear(int y)
	{
		car.setYearModel(y);
	}
	public void setCarSpeed()
	{
		car.accelerate();
	}
	
	public void updateCarView ()
	{
		carView.printCarDetails(car.getYearModel(), car.getMake(), car.getSpeed());
	}
}
