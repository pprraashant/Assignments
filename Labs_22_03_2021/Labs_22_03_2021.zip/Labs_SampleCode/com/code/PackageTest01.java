package com.code;
class PackageTest
{
public static void main(String [] args)
{
System.out.println("Inside PackageTest01");
}
}