package com.code;
public class PackageTest
{
public static void main(String [] args)
{
System.out.println("Inside PackageTest");
}
}