class HelloWorld
{
String message;
static String iamstatic="static Variable";
public static void main(String arg [])
{
int v=10000000;
System.out.println("Hello World "+ arg[0]);
System.out.println("Value of Variable a= "+v);
//System.out.println("Value of Instance Variable in Main= "+message);
HelloWorld helo= new HelloWorld();
System.out.println(helo.message);
System.out.println("Static variale of helo"+helo.iamstatic);
HelloWorld helo2= new HelloWorld();
helo2.message="This is instance variable of class HelloWorld";
System.out.println(helo2.message);
System.out.println("Static variale of helo2"+helo2.iamstatic);
helo2.iamstatic="new static variable value";
System.out.println("Static variale of helo"+helo.iamstatic);
System.out.println("Static variale of helo2"+helo2.iamstatic);
System.out.println("Static variale accessed using class"+HelloWorld.iamstatic);
helo.print();
//helo.main(new String [] {"fromClassItself"});
}

public void print()
{
System.out.println("InSide Print Method of Class HelloWorld");
}
}
