public class Car implements genericCar,CarRules,GovCarPolicies
{
int speed; 
boolean isEngineOn;
boolean acStatus;
int acValue;

void speedUp(int increaseSpeedBy)
{
	speed=speed + increaseSpeedBy;
}

void turnOnCar()
{
	isEngineOn=true;
}

void turnOffCar()
{
isEngineOn=false;
}

public static void main(String [] args)
{
Car mahindraCar= new Car(); 
Car teslaCar= new Car(); 

System.out.println("Is Car turn On "+car.isEngineOn);
car.turnOnCar();
System.out.println("Is Car turn On after access behaviour turnOnCar"+car.isEngineOn);

}

}