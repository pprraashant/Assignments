class first
{
int a=12;
{
int a=0;
System.out.println("value of a= "+a);
}
static {
int a1=11;
System.out.println("value of static a1= "+a1);
}

public static void main(String [] a)
{

System.out.println("inside Main");
first f= new first();
System.out.println("inside Main value of a from block "+f.a);
}

}