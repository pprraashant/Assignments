public class TwoClass
{

public static void main(String [] ag)
{
System.out.println("InsideTwoClass");
}
}
class A
{}