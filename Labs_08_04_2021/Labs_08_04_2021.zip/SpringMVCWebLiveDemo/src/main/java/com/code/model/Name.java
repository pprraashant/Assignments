package com.code.model;

public class Name {
	
	String name;

	public Name() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
