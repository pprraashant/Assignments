package com.code.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.code.model.Name;
import com.code.service.GreetingService;

@Controller
//@RequestMapping("/main")
public class MainController {
	
	private static final Logger logger = LoggerFactory.getLogger(MainController.class);
	@Autowired
	GreetingService greetingservice;
	
	@ResponseBody
	@GetMapping(value ="/message", consumes = "text/html")
	public String sendMessage()
	{
		logger.info("inside consume narrowed down controller handler");
		return greetingservice.greet();
	}
	@ResponseBody
	@GetMapping(value ="/message", produces = org.springframework.http.MediaType.TEXT_HTML_VALUE)
	public String sendMessageMediaType()
	{
		logger.info("inside produce narrowed down controller handler");
		return greetingservice.greet();
	}
	
	@ResponseBody
	@PostMapping(value ="/message",consumes = "*",produces = "*")
	public Name sendMessageMediaTypePost(@ModelAttribute Name name)
	{
		logger.info("inside produce narrowed down controller handler"+ name.getName());
		return name;
	}
	
	@RequestMapping (value= "/", method=RequestMethod.GET, params="a=10")
	public String displayMessage(Model model)
	{
		logger.info("i am inside displayMessage with param as a=10");
		model.addAttribute("message",greetingservice.greet());
		model.addAttribute("newmsg","I am new Message");
		return "home";
	}
	
	@RequestMapping (value= "/", method=RequestMethod.GET)
	public String displayMessageWithOutParam(Model model)
	{
		logger.info("i am inside displayMessageWithOutParam");
		logger.debug("Details Message about request");
		model.addAttribute("message",greetingservice.greet());
		model.addAttribute("newmsg","I am new Message");
		return "home";
	}
	
	@RequestMapping (path= "/{id}", method=RequestMethod.GET)
	@ResponseBody
	public String displayMessageWithoutView(Model model,@PathVariable int id,@RequestParam int a,
			@RequestHeader("Accept-Encoding") String encoding, 
	        @RequestHeader("Cookie") String keepAlive)
	{
		logger.info("i am inside displayMessageWithoutView with id "+id+ "param as a="+a);
		logger.info("i am inside displayMessageWithoutView with Accept-Encoding "+encoding+ "keepAlive="+keepAlive);
		model.addAttribute("message",greetingservice.greet());
		return "Id is "+id +"queryParam "+ a;
	}
	@GetMapping("/home")
	public String displayMessageWithGetMapping(Model model)
	{
		logger.info("i am inside displayMessageWithGetMapping");
		model.addAttribute("message",greetingservice.greet());
		model.addAttribute("newmsg","Using Model add attribute");
		return "home";
	}
	
	@GetMapping("/all")
	@ResponseBody
	public String all(Model model)
	{
		logger.info("i am inside all");
		model.addAttribute("message",greetingservice.greet());
		return "home";
	}
	
	
	@GetMapping("/res")
	@ResponseBody
	public ResponseEntity<String> reponseEntity(Model model)
	{
		logger.info("i am inside all");
		model.addAttribute("message",greetingservice.greet());
		//return ResponseEntity.ok().body("I am inside ResponseEntity");
		return ResponseEntity.ok().body("Some wrong inputs provided");
	}
	

}
