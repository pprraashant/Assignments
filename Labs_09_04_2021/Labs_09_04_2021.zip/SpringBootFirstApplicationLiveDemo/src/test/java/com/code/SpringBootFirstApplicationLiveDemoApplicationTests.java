package com.code;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFirstApplicationLiveDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
